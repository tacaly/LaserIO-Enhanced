package com.direwolf20.laserio.common.items.upgrades;

import com.direwolf20.laserio.setup.ModSetup;
import net.minecraft.world.item.Item;

public class OverclockerNode extends Item {
    public OverclockerNode() {
        super(new Item.Properties().tab(ModSetup.ITEM_GROUP));
    }
}
