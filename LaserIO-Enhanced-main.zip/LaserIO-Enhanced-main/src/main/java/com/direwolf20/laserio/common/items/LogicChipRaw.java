package com.direwolf20.laserio.common.items;

import com.direwolf20.laserio.setup.ModSetup;
import net.minecraft.world.item.Item;

public class LogicChipRaw extends Item {

    public LogicChipRaw() {
        super(new Item.Properties().tab(ModSetup.ITEM_GROUP));
    }
}
