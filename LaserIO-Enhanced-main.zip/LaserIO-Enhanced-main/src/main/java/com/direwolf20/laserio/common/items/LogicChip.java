package com.direwolf20.laserio.common.items;

import com.direwolf20.laserio.setup.ModSetup;
import net.minecraft.world.item.Item;

public class LogicChip extends Item {

    public LogicChip() {
        super(new Item.Properties().tab(ModSetup.ITEM_GROUP));
    }
}
