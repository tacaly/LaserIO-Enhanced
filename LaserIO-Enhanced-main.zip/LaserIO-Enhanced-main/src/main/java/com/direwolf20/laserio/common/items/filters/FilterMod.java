package com.direwolf20.laserio.common.items.filters;

public class FilterMod extends FilterBasic {
    public FilterMod() {
        super();
    }
}
