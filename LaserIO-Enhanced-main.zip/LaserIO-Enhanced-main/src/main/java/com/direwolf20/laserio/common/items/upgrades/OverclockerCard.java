package com.direwolf20.laserio.common.items.upgrades;

import com.direwolf20.laserio.setup.ModSetup;
import net.minecraft.world.item.Item;

public class OverclockerCard extends Item {
    public OverclockerCard() {
        super(new Item.Properties().tab(ModSetup.ITEM_GROUP));
    }
}
